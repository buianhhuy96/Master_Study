close all
I = imread("peppers.png");

A = 0:255;
% Define step value/minimum value of discretized array 
step = 256/4;

% discretized A array with a defined step
% QA1 contains A elements rounded to nearest multiple of step.
QA1 = quant(A, step);

% Defind a sequence with fixed step size
% In this case, start: "step", end: "256-step", step size: "step"
partition = step:step:256-step;

% Define a sequence with fixed step size
% In this case, start: "step/2", end: "256-step/2", step size: "step"
codebook = step/2:step:256-step/2;

% Decide the index by comparing elements in A to in partition array:
% Return: indx
% With the index retrieved, return elements from codebook array.
% Return: QA2
[indx,QA2] = quantiz(A, partition, codebook);

fprintf('\n QA1: [') ;
fprintf(' %d ', unique(QA1)) ;
fprintf(']\n') ;

fprintf('\n QA2: [') ;
fprintf(' %d ', unique(QA2)) ;
fprintf(']\n') ;