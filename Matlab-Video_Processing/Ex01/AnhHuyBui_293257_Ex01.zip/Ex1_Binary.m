Img = [0 0 0 0 0 0 0 1 1 0,
       1 0 0 1 0 0 1 0 0 1, 
       1 0 0 1 0 1 1 0 0 0,
       0 0 1 1 1 0 0 0 0 0,
       0 0 1 1 1 0 0 1 1 1];
% count non-zero elements in 2 subsets
fprintf('%d\n',nonzeroCount(Img(1:4,2:5)));
fprintf('%d\n',nonzeroCount(Img(1:4,6:9)));

% load S matrix and count non-zero elements 
S = load('S.mat').S;
fprintf('%d\n',nonzeroCount(S));


function output=nonzeroCount(S)
    % return a true(1)/false(0) (binary) array 
    % which check if element of input is not zero
    nonzeroPixel = (S ~= 0);
    % sum all of true in binary array to get total non-zero elements 
    output = sum(nonzeroPixel,'all');
    
end