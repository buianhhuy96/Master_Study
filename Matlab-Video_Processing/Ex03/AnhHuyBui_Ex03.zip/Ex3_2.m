clear all;
close all;
I = imread("mbaboon.bmp");
% Define functions for down sampling
fun1 = @(block_struct) block_struct.data(2,2);
fun2 = @(block_struct) block_struct.data(1,1);
fun3 = @(block_struct) mean2(block_struct.data);

% Plot down-sampled images with defined functions
subplot(1,3,1), imshow(blockproc(I,[4 4],fun1)), title('mbaboon [2 2]');
subplot(1,3,2), imshow(blockproc(I,[4 4],fun2)), title('mbaboon [1 1]');
subplot(1,3,3), imshow(uint8(blockproc(I,[4 4],fun3))), title('mbaboon average intensity');


% 3.3
%  The phenomenon of the situation is because when being in the bright sunlight, pupil of the eyes contracts 
%  so as to prevent too much light coming in, which can damage the eyes. When we go in the dark, the pupil expands to
%  collect more light so we can see. So we may be "blind" as first until pupil is wide enough.

%3.4
%	a. If c < 0, the whole histogram shifts left due to (a same amount) decrease in gray level of all pixels.
%	   In constrast, if c > 0, histogram shifts right.
%	b. If c > 1, the whole histogram shifts right and expands because each pixel is added with itself.
%	   The higher is added with higher value and vice versa.
%	   If c > 1, the whole histogram shifts left and narrows down
%	c. histogram remains unchange due to no changes are made into the gray level of pixels or number of pixels,
%		just the position of pixels change.