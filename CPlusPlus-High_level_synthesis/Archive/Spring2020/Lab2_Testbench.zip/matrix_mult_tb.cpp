#include "stdio.h"
#include "iostream"
#include <iomanip>
#include "mc_scverify.h"
#include "matrix_mult.h"
#include <fstream>
#include <string>
#include <sstream>
// Issue:
// In the case of transpose = 1, 
// the results from HLS function = -the results from reference function.
// In other words, the results are the same when transpose = 4.
// So B matrix (second input) passed to the function is transposed accidentally.
//
// Solution:
// Swap row and column of B matrix in the case of  transpose = 1.
CCS_MAIN(int argc, char *argv[]) 
{
	const int MAX_TRANSPOSE = 3;
	const int MATRIX_SIZE = N;
	int transpose = 0;
	
	// This variable is a return value from the testbench 
	// (0 indicates passing the testbench, 1 failing it).
	int ret = 0;
	
	// This Catapult macro calls the design and passes the variables to it.
	
	// Open output file named "matrix_mult_output.txt" for writing.
	std::ofstream file_object("matrix_mult_output.txt");
	
	// Create variables to be passed to the design
	// Inputs:			 A, B matrixes
	// Output: 			 C_hls matrix
	// Output reference: C matrix
	hls_data_t A[MATRIX_SIZE][MATRIX_SIZE] = {0};
	hls_data_t B[MATRIX_SIZE][MATRIX_SIZE] = {0};
	hls_result_t C_hls[MATRIX_SIZE][MATRIX_SIZE] = {0};
	hls_result_t C[MATRIX_SIZE][MATRIX_SIZE] = {0};
    
	
	// Test cases are created with different value of transpose to
	// test the two matrix multiplication designs against each other.
	for (transpose = 0; transpose <= MAX_TRANSPOSE; transpose++){
	    file_object << "Transpose = " << transpose << std::endl;
		int matrix_row = 0;
		int matrix_height = 0;
		
		// 	* Generate the input values for the test
		//	  A[i][j] = i+j
		//    B[i][j] = i-j
		for (matrix_row = 0; matrix_row < MATRIX_SIZE; matrix_row++){
			for (matrix_height = 0; matrix_height < MATRIX_SIZE; matrix_height++){
				A[matrix_row][matrix_height] = matrix_row+matrix_height;
				B[matrix_row][matrix_height] = matrix_row-matrix_height;
			}
		}
		
		// Call the testing function and pass variables to it 
		// and get the result of multiplication.
		CCS_DESIGN(matrixMultHLS)(A, B, C_hls, transpose);
		// Call the reference function and pass variables to it
		// and get the reference result.
		matrixMult(A, B, C, transpose);
		// Going through each elements of the result matrixes.
		for (matrix_row = 0; matrix_row < MATRIX_SIZE; matrix_row++){
			std::string line="";
			for (matrix_height = 0; matrix_height < MATRIX_SIZE; matrix_height++){
				// If the result from testing function is different from reference one
				if (C_hls[matrix_row][matrix_height] != C[matrix_row][matrix_height]){
					std::stringstream ss;
				    std::string output_string = "";
					// Create output result. 
				   	ss << C_hls[matrix_row][matrix_height] << "/" <<  "(" 
					   << C[matrix_row][matrix_height] << ")";
					output_string = ss.str();
					file_object << std::setw(12) << std::right;
	       		    file_object << output_string;
					ret = 1;
				}
				// If no difference detected
				else{
					// Print correct value
				    file_object << std::setw(11) << std::right;
					file_object << C_hls[matrix_row][matrix_height] << " ";
				}
			}
				file_object << std::endl;
		}
	    file_object << std::endl;
	}
	
	// Generate report of the test.
	file_object << "TEST DONE! Check result below:" << std::endl;
	if(ret){
	    file_object << 
		"The wrong values are descibed with a value next to them in brackets, which are the correct values.";
	}
	else {
	    file_object << "Test passed! All values are correct.";
	}
	
	// Close the report file
	file_object.close();
	
	CCS_RETURN(ret);
	
}
